import { Injectable } from '@angular/core';
import { HttpClient } from "@angular/common/http";
import 'rxjs/add/operator/map';
import { environment } from './../../environments/environment';
export interface UserResponse {
   user:string,
   data:string
}
@Injectable()
export class SuperAdminService {
    public activeToken: String;
    public data:any
    constructor(private http: HttpClient) {
        
    }
   
    postUserLogin(data: any) {
        return this.http.post<UserResponse>(environment.BASE_URL + '/user-login/', data).map(res => res);
    }
    addAdmin(data: any) {
        return this.http.post<UserResponse>(environment.BASE_URL + '/addadmin/', data).map(res => res);
    }
     getAdmin(page:any) {
        return this.http.get<UserResponse>(environment.BASE_URL + 'users?page='+page).map(res => res);
    }
     deleteUserapi(data:any) {
        return this.http.post<UserResponse>(environment.BASE_URL + '/deleteuser/',data).map(res => res);
    }
     updateUser(data:any) {
        return this.http.post<UserResponse>(environment.BASE_URL + '/updateUser/',data).map(res => res);
    }
     activeUser(data:any) {
        return this.http.post<UserResponse>(environment.BASE_URL + '/active-user/',data).map(res => res);
    }
     inactiveUser(data:any) {
        return this.http.post<UserResponse>(environment.BASE_URL + '/inactive-user/',data).map(res => res);
    }
    searchUser(data:any) {
        return this.http.get<UserResponse>(environment.BASE_URL + 'search/?search='+data).map(res => res);
    }
    
}