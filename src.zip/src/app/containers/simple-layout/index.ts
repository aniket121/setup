export * from './simple-layout.component';
