import { Component, OnInit,Input,Output, EventEmitter } from '@angular/core';
import { RouterModule, Router } from '@angular/router';


@Component({
  selector: 'app-table',
  templateUrl: './data-table.component.html',
  styleUrls: ['./data-table.component.scss']
})
export class DataTableComponent implements OnInit {

   @Input() showImportDialog:Boolean=false;
   @Input() header:string;
   @Output() messageEvent = new EventEmitter<any>();
   @Output() ObjectEvent = new EventEmitter<any>();
   @Output() prevNextEvent = new EventEmitter<any>();
   @Output() prevEvent = new EventEmitter<any>();
   @Output() searchInput = new EventEmitter<any>();
   @Output() deleteEvent = new EventEmitter<any>();
   @Input() users:any
   @Input() buttonName:any;
   public showsecond:Boolean=false;
   public transactions: {
      contact_date: Date,
      name: string,
      email: number,
      TAT:number,
      FAT:number,
      Fax_N0:number,
      cite:string,
      state:string,
      pincode:number,
      street:string,
      country:string,
      action:any

    }[];
  public customer={};
  public customerAssociation={};
  public deleteDialog:Boolean=false;
  public tabStatus:Boolean=true;
  public contract={};
  subAccount=[]
  public SubAccount:Boolean=false;
  constructor(private router: Router) {
   }

  ngOnInit() {
      
  }
  secondDialog(){
  this.showsecond = !this.showsecond;
  }
  showCustomerDialog()
  { 
    this.showImportDialog = !this.showImportDialog;
    //this.modal_title = "Add Customer";
    this.messageEvent.emit('')
  }
  edit(data:any){
    console.log("in child edit",data)
    this.showCustomerDialog()
    this.ObjectEvent.emit(data)
  }
  delete(data:any){
    console.log("in child edit",data)
    this.secondDialog()
    this.deleteEvent.emit(data)
  }
  saveCustomer()
  {
    console.log(" in save save customer api",this.customer);
    this.tabStatus=false;
  }
  customerAssociationHandler()
  {
    console.log("customer assocation",this.customerAssociation);
  }
  addSubAccount(subAccountObject:any)
  {
     console.log("sub account",subAccountObject)
     this.subAccount.push(subAccountObject);
     console.log("subaccount",this.subAccount);
  }
  addcontract(contract:any)
  {
     console.log("sub account",contract)
  }
  SelectTabContent(Content:any)
  {
    if(Content=="SubAccount")
    {
      this.SubAccount=true;
    }
    else{
      this.SubAccount=false;
    }
  }
  
  getNextPrevRecors(values:any){
   console.log(values)
   this.prevNextEvent.emit(values)
  }
  getPrevRecors(values:any){
   console.log(values)
   this.prevEvent.emit(values)
  }
  Search(values:any){
    console.log(values)
     this.searchInput.emit(values)
  }
}
