

const ApiUrl='https://jsonplaceholder.typicode.com';
export default ApiUrl;