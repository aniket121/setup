import { Component } from '@angular/core';

@Component({
  selector: 'app-dashboard',
  templateUrl: './simple-layout.component.html',
  styleUrls:['./simple-layout.component.css']
})
export class SimpleLayoutComponent { }
