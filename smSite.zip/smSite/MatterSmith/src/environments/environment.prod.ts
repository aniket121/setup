export const environment = {
  production: true,
  // BASE_URL: 'http://127.0.0.1:8000',
  BASE_URL : 'http://192.168.0.168:8000',
};
